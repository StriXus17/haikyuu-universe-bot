# Blank Flask Application

### Prerequisites
- Python
- Pip
- Flask

Run `python app.py`

#### Go to "localhost:4000" in your browser